package com.pagesociety.util;

public class CALLBACK
{

	public static final Object CALLBACK_VOID = new Object();
	public Object exec(Object... args) throws Exception
	{
		return CALLBACK_VOID;
	}
}