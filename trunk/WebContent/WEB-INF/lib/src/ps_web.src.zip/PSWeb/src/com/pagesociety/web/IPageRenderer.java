package com.pagesociety.web;

public interface IPageRenderer
{
	public String render();
	public void render(StringBuilder b);
}
