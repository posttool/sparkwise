package com.pagesociety.web.page;

public interface IEditor
{
}
