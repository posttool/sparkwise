package com.pagesociety.web;

public class ApplicationConstants
{
	public static final String TEMP_DIR_KEY = "javax.servlet.context.tempdir";
	public static final String USER_CONTEXT_SESSION_KEY = "com.pagesociety.web.user";
}
