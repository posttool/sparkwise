package com.pagesociety.bdb.index.query;

public class QueryExecutorConfig
{

}
