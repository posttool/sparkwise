package com.pagesociety.bdb.index.freetext;

public interface FreetextStemmer 
{
	public String stem(String s);
}
