package com.pagesociety.bdb.index.freetext;

public interface StopList
{

	public  boolean isStop(String word);
}
